--Componentes do Grupo

---RM 552421 - Flavio Sousa Vasconcelos
---RM  97887 - Jo�o Carlos Fran�a Figueiredo
---RM 550200 - Leonardo Oliveira Esparza
---RM 552368 - Wellington Urcino

-- Conectar ao banco de dados
CONNECT rm552421/090478@//oracle.fiap.com.br:1521/ORCL

@"E:\Challenge_2024-Sprint01\Fiap - Challenge.sql";

--Criando as tabelas

---tabela usu�rios cont�m informa��es do linkedin do usu�rio

CREATE TABLE usuarios (
    id            NUMBER(10) PRIMARY KEY,
    nome          VARCHAR2(100) NOT NULL,
    email         VARCHAR2(100),
    linkedin_id   VARCHAR2(100) UNIQUE,
    data_cadastro DATE NOT NULL
);

-- tabela recrutadores cont�m 
CREATE TABLE recrutadores (
    id      NUMBER(10) PRIMARY KEY,
    nome    VARCHAR2(100) NOT NULL,
    empresa VARCHAR2(100)
);

--tabela curriculo cont�m informa��es do curriculo dos usuarios
CREATE TABLE curriculo (
    id          NUMBER(10) PRIMARY KEY,
    conteudo    CLOB,
    usuario_id  NUMBER(10) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- tablea IA contem as analises do com base nos curriculos dos usuarios
CREATE TABLE ia (
    id                   NUMBER(10) PRIMARY KEY,
    analise              CLOB,
    data_analise         DATE,
    curriculo_id         NUMBER(10) NOT NULL,
    curriculo_usuario_id NUMBER(10) NOT NULL,
    CONSTRAINT fk_curriculo FOREIGN KEY (curriculo_id) REFERENCES curriculo(id)
);

-- tabela empresas contem as informa��es das empresas
CREATE TABLE empresas (
    id              NUMBER(10) PRIMARY KEY,
    nome            VARCHAR2(100) NOT NULL,
    localizacao     VARCHAR2(100),
    recrutador_id   NUMBER(10) NOT NULL,
    ia_id           NUMBER(10) NOT NULL
);

ALTER TABLE empresas ADD CONSTRAINT fk_recrutador FOREIGN KEY (recrutador_id) REFERENCES recrutadores(id);

ALTER TABLE empresas ADD CONSTRAINT fk_ia FOREIGN KEY (ia_id) REFERENCES ia(id);



--Ingest�o em tabelas

-- Insert de dados em USUARIOS
INSERT INTO usuarios (id, nome, email, linkedin_id, data_cadastro)
VALUES (1, 'Jo�o Silva', 'joao@example.com', 'joaosilva123', TO_DATE('2024-04-01', 'YYYY-MM-DD'));
INSERT INTO usuarios (id, nome, email, linkedin_id, data_cadastro)
VALUES (2, 'Maria Santos', 'maria@example.com', 'mariasantos456', TO_DATE('2024-04-02', 'YYYY-MM-DD'));
INSERT INTO usuarios (id, nome, email, linkedin_id, data_cadastro)
VALUES (3, 'Pedro Oliveira', 'pedro@example.com', 'pedrooliveira789', TO_DATE('2024-04-03', 'YYYY-MM-DD'));
INSERT INTO usuarios (id, nome, email, linkedin_id, data_cadastro)
VALUES (4, 'Ana Pereira', 'ana@example.com', 'anapereira1011', TO_DATE('2024-04-04', 'YYYY-MM-DD'));
INSERT INTO usuarios (id, nome, email, linkedin_id, data_cadastro)
VALUES (5, 'Carlos Ferreira', 'carlos@example.com', 'carlosferreira1213', TO_DATE('2024-04-05', 'YYYY-MM-DD'));

-- Insert de dados em RECRUTADORES
INSERT INTO recrutadores (id, nome, empresa)
VALUES (1, 'Ana Costa', 'Empresa A');
INSERT INTO recrutadores (id, nome, empresa)
VALUES (2, 'Bruno Oliveira', 'Empresa B');
INSERT INTO recrutadores (id, nome, empresa)
VALUES (3, 'Clara Silva', 'Empresa C');
INSERT INTO recrutadores (id, nome, empresa)
VALUES (4, 'Diego Santos', 'Empresa D');
INSERT INTO recrutadores (id, nome, empresa)
VALUES (5, 'Elaine Pereira', 'Empresa E');

-- Insert de dados em CURRICULO
INSERT INTO curriculo (id, conteudo, usuario_id)
VALUES (1, 'Experi�ncia em desenvolvimento web.', 1);
INSERT INTO curriculo (id, conteudo, usuario_id)
VALUES (2, 'Experi�ncia em gerenciamento de projetos.', 2);
INSERT INTO curriculo (id, conteudo, usuario_id)
VALUES (3, 'Experi�ncia em an�lise de dados.', 3);
INSERT INTO curriculo (id, conteudo, usuario_id)
VALUES (4, 'Experi�ncia em marketing digital.', 4);
INSERT INTO curriculo (id, conteudo, usuario_id)
VALUES (5, 'Experi�ncia em suporte t�cnico.', 5);

-- Insert de dados em IA
INSERT INTO ia (id, analise, data_analise, curriculo_id, curriculo_usuario_id)
VALUES (1, 'An�lise positiva.', TO_DATE('2024-04-01', 'YYYY-MM-DD'), 1, 1);
INSERT INTO ia (id, analise, data_analise, curriculo_id, curriculo_usuario_id)
VALUES (2, 'An�lise neutra.', TO_DATE('2024-04-02', 'YYYY-MM-DD'), 2, 2);
INSERT INTO ia (id, analise, data_analise, curriculo_id, curriculo_usuario_id)
VALUES (3, 'An�lise negativa.', TO_DATE('2024-04-03', 'YYYY-MM-DD'), 3, 3);
INSERT INTO ia (id, analise, data_analise, curriculo_id, curriculo_usuario_id)
VALUES (4, 'An�lise positiva.', TO_DATE('2024-04-04', 'YYYY-MM-DD'), 4, 4);
INSERT INTO ia (id, analise, data_analise, curriculo_id, curriculo_usuario_id)
VALUES (5, 'An�lise neutra.', TO_DATE('2024-04-05', 'YYYY-MM-DD'), 5, 5);

-- Insert de dados em EMPRESAS
INSERT INTO empresas (id, nome, localizacao, recrutador_id, ia_id)
VALUES (1, 'Empresa X', 'Cidade A', 1, 1);
INSERT INTO empresas (id, nome, localizacao, recrutador_id, ia_id)
VALUES (2, 'Empresa Y', 'Cidade B', 2, 2);
INSERT INTO empresas (id, nome, localizacao, recrutador_id, ia_id)
VALUES (3, 'Empresa Z', 'Cidade C', 3, 3);
INSERT INTO empresas (id, nome, localizacao, recrutador_id, ia_id)
VALUES (4, 'Empresa W', 'Cidade D', 4, 4);
INSERT INTO empresas (id, nome, localizacao, recrutador_id, ia_id)
VALUES (5, 'Empresa V', 'Cidade E', 5, 5);

---CRIA��O DOS BLOCOS

-- Bloco an�nimo 1
BEGIN
    -- Consulta 1: Join entre as tabelas CURRICULO e USUARIOS
    FOR curriculo_data IN (
        SELECT c.id AS curriculo_id, c.conteudo, u.nome AS usuario_nome
        FROM curriculo c
        JOIN usuarios u ON c.usuario_id = u.id
        ORDER BY c.id
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Curriculo ID: ' || curriculo_data.curriculo_id || ', Conteudo: ' || curriculo_data.conteudo || ', Usuario: ' || curriculo_data.usuario_nome);
    END LOOP;
    
    -- Consulta 2: Join entre as tabelas IA e EMPRESAS
    FOR ia_data IN (
        SELECT ia.curriculo_id, ia.analise, e.nome AS empresa_nome
        FROM ia
        JOIN empresas e ON ia.curriculo_id = e.id -- Corrigido para ia.curriculo_id
        ORDER BY ia.curriculo_id -- Corrigido para ia.curriculo_id
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Curriculo ID: ' || ia_data.curriculo_id || ', Analise: ' || ia_data.analise || ', Empresa: ' || ia_data.empresa_nome);
    END LOOP;
    
    -- Consulta 3: Join entre as tabelas RECRUTADORES e EMPRESAS com agrupamento
    FOR recrutadores_data IN (
        SELECT r.nome AS recrutador_nome, e.nome AS empresa_nome, COUNT(*) AS total_empresas
        FROM recrutadores r
        JOIN empresas e ON r.id = e.recrutador_id
        GROUP BY r.nome, e.nome
        ORDER BY r.nome, e.nome
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Recrutador: ' || recrutadores_data.recrutador_nome || ', Empresa: ' || recrutadores_data.empresa_nome || ', Total de empresas: ' || recrutadores_data.total_empresas);
    END LOOP;
END;
/

-- Bloco an�nimo 2

DECLARE
BEGIN
    -- Consulta 1: Join entre as tabelas USUARIOS e IA
    FOR usuarios_ia_data IN (
        SELECT u.nome AS usuario_nome, ia.analise, ia.data_analise
        FROM usuarios u
        JOIN ia ON u.id = ia.curriculo_usuario_id
        ORDER BY u.nome, ia.data_analise
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Usuario: ' || usuarios_ia_data.usuario_nome || ', Analise: ' || usuarios_ia_data.analise || ', Data de Analise: ' || TO_CHAR(usuarios_ia_data.data_analise, 'YYYY-MM-DD'));
    END LOOP;


    -- Consulta 2: Join entre as tabelas CURRICULO e EMPRESAS com agrupamento
    FOR curriculo_empresas_data IN (
        SELECT c.id AS curriculo_id, c.conteudo, COUNT(*) AS total_empresas
        FROM curriculo c
        JOIN empresas e ON c.usuario_id = e.id -- Corre��o na condi��o de join
        GROUP BY c.id, c.conteudo
        ORDER BY c.id, c.conteudo
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Curriculo ID: ' || curriculo_empresas_data.curriculo_id || ', Conteudo: ' || curriculo_empresas_data.conteudo || ', Total de empresas: ' || curriculo_empresas_data.total_empresas);
    END LOOP;



    -- Consulta 3: Join entre as tabelas RECRUTADORES e EMPRESAS com ordena��o
    FOR recrutadores_empresas_data IN (
        SELECT r.nome AS recrutador_nome, e.nome AS empresa_nome
        FROM recrutadores r
        JOIN empresas e ON r.id = e.recrutador_id
        ORDER BY r.nome, e.nome
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Recrutador: ' || recrutadores_empresas_data.recrutador_nome || ', Empresa: ' || recrutadores_empresas_data.empresa_nome);
    END LOOP;
END;
/

commit;